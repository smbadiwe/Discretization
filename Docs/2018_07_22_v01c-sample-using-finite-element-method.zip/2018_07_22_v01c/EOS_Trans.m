% Using EOS to define the species density at each cell and face center.

k=k;

for i = 1:cellnum-1
    MeshPress(i+1,k) = (MatrixPress(i,k)+MatrixPress(i+1,k))/2;
    MeshTemp(i+1,k) = (MatrixTemp(i,k)+MatrixTemp(i+1,k))/2;
    MeshFrac_CH4(i+1,k) = (MatrixFrac_CH4(i,k)+MatrixFrac_CH4(i+1,k))/2;
    MeshFrac_CO2(i+1,k) = (MatrixFrac_CO2(i,k)+MatrixFrac_CO2(i+1,k))/2;
    MeshFrac_H2O(i+1,k) = (MatrixFrac_H2O(i,k)+MatrixFrac_H2O(i+1,k))/2;
    MeshFrac_CO(i+1,k) = (MatrixFrac_CO(i,k)+MatrixFrac_CO(i+1,k))/2;
    MeshFrac_H2(i+1,k) = (MatrixFrac_H2(i,k)+MatrixFrac_H2(i+1,k))/2;
    MeshFrac_N2(i+1,k) = (MatrixFrac_N2(i,k)+MatrixFrac_N2(i+1,k))/2;
    MeshFrac_O2(i+1,k) = (MatrixFrac_O2(i,k)+MatrixFrac_O2(i+1,k))/2;
end

i = facenum; % This is not preferred, btw. Fix this. 
MeshPress(i,k) = MatrixPress(i-1,k);
MeshTemp(i,k) = MatrixTemp(i-1,k);
MeshFrac_CH4(i,k) = MatrixFrac_CH4(i-1,k);
MeshFrac_CO2(i,k) = MatrixFrac_CO2(i-1,k);
MeshFrac_H2O(i,k) = MatrixFrac_H2O(i-1,k);
MeshFrac_CO(i,k) = MatrixFrac_CO(i-1,k);
MeshFrac_H2(i,k) = MatrixFrac_H2(i-1,k);
MeshFrac_N2(i,k) = MatrixFrac_N2(i-1,k);
MeshFrac_O2(i,k) = MatrixFrac_O2(i-1,k);

MatrixTestDens = MatrixDens;

for i = 1:cellnum
    
    P = MatrixPress(i,k); T = MatrixTemp(i,k); xCH4 = MatrixFrac_CH4(i,k);
    xCO2 = MatrixFrac_CO2(i,k); xH2O = MatrixFrac_H2O(i,k);
    xCO = MatrixFrac_CO(i,k); xH2 = MatrixFrac_H2(i,k); 
    xN2 = MatrixFrac_N2(i,k); xO2 = MatrixFrac_O2(i,k); 
    MatrixDens(i,k) = Mix_Dens(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2);
    Matrix_Mu(i,k) = Mix_Visc(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2);
    
    % Getting mean mass density (g/mol) for gas mixture. 
    mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
    mN2 = 28.02; mO2 = 32.00;
    MoltoMass = mCH4*xCH4 + mCO*xCO + mCO2*xCO2 + mH2*xH2 + mH2O*xH2O + ...
        mN2*xN2 + mO2*xO2;

    % mol/m^3 = kg/m^3 / (g/mol *(1 kg/1000g)
    MatrixDensM(i,k) = MatrixDens(i,k) / (MoltoMass/1000);
    
end

for i = 1:facenum
    
    P = MeshPress(i,k); T = MeshTemp(i,k); xCH4 = MeshFrac_CH4(i,k);
    xCO2 = MeshFrac_CO2(i,k); xH2O = MeshFrac_H2O(i,k);
    xCO = MeshFrac_CO(i,k); xH2 = MeshFrac_H2(i,k); 
    xN2 = MeshFrac_N2(i,k); xO2 = MeshFrac_O2(i,k); 
    diff = Mix_MolDiff(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2);
    
    Mesh_mu(i,k) = Mix_Visc(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2);
    Mesh_cond(i,k) = Mix_Cond(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2);
    MeshCp(i,k) = Mix_Cp(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2);
    MeshDens(i,k) = Mix_Dens(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2);
    Mesh_DCH4(i,k) = diff(1,1);
    Mesh_DCO(i,k) = diff(2,1);
    Mesh_DCO2(i,k) = diff(3,1);
    Mesh_DH2(i,k) = diff(4,1);
    
    % Getting mean mass density (g/mol) for gas mixture. 
    mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
    mN2 = 28.02; mO2 = 32.00;
    MoltoMass = mCH4*xCH4 + mCO*xCO + mCO2*xCO2 + mH2*xH2 + mH2O*xH2O + ...
        mN2*xN2 + mO2*xO2;

    % mol/m^3 = kg/m^3 / (g/mol *(1 kg/1000g)
    MeshDensM(i,k) = MeshDens(i,k) / (MoltoMass/1000);
    
end