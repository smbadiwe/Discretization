function H2OCond = IAPWS_Cond(T, rho)

% The thermal conductivity of water is calculated based on "Revised Release
% on the IAPS Formulation 1985 for the Thermal Conductivity of Ordinary
% Water Substance" from the International Association for the Properties of
% Water and Steam.

% Data taken from:
% Wagner, W., Kretzschmar, H-J. (2008). International Steam Tables (2nd
% Ed.). Berlin, Germany: Springer-Verlag. 

theta = T / 647.096; % critical temperature divided by actual temperature
delta = (rho * 18.02 / 1000) / 322; % actual mass dens. divided by critical density

% Coefficients for reduced temperature contribution. 
coeff1 =   [1 0.0102811
            2 0.0299621
            3 0.0156146
            4 -0.00422464];

% Coefficients for reduced volume contribution. 
n1 = -0.397070;
n2 = 0.400302;
n3 = 1.06000;
n4 = -0.171587;
n5 = 2.39219;

% Coefficients for reduced temperature and volume interaction term. 
m1 = 0.0701309;
m2 = 0.0118520;
m3 = 0.642857;
m4 = 0.00169937;
m5 = -1.02000;
m6 = -4.11717;
m7 = -6.17937;
m8 = 0.0822994;
m9 = 10.0932;
m10 = 0.00308976;

term1sum = 0;
for i = 1:4
    term1sum = term1sum + coeff1(i,2) * theta ^ (i-1);
end

% Reduced temperature and volume terms. 
lambda0 = (theta ^ 0.5) * term1sum;
lambda1 = n1 + n2 * delta + n3 * exp(n4 * (delta + n5) ^ 2);

termA = 2 + m8 * (abs(theta-1)+m10) ^ -0.6;

if theta >= 1
    termB = (abs(theta-1)+m10) ^ -1;
else
    termB = m9 * ((abs(theta-1)+m10)^-0.6);
end

% Combined reduced temperature and volume term. 
lambda2 = (m1 * (theta ^ -10) + m2) * (delta ^ 1.8) * exp(m3 * (1 - ...
    (theta ^ 1.8))) + m4 * termA * (delta ^ termB) * exp((termB / ...
    (1 + termB) * (1 - (delta ^ (1 + termB))))) + m5 * exp(m6 * ...
    (theta ^ 1.5) + m7 * (delta ^ -5));

% Sum terms to find thermal conductivity, in W/m.K
H2OCond = lambda0 + lambda1 + lambda2;

end