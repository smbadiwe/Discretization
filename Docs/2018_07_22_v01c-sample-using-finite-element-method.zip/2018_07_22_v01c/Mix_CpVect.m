function TotalCpVect = Mix_CpVect(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2, i)
    
    pickle = P; %#ok<NASGU> - Just a silly variable to "use" pressure.
    igloo = i; %#ok<NASGU> - Just a silly variable to "use" index.
    
    % Heat capacity is taken as the sum of products of individual species
    % heat capacities and their molar fractions. 
    CalcCp = Poly_Cp(T,1).*xCH4 + Poly_Cp(T,2).*xCO2 + Poly_Cp(T,3).*xH2O +...
        Poly_Cp(T,4).*xCO + Poly_Cp(T,5).*xH2 + Poly_Cp(T,6).*xN2 + ...
        Poly_Cp(T,7).*xO2;
    
    % Getting mean mass density (g/mol) for gas mixture. 
    mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
    mN2 = 28.02; mO2 = 32.00;
    MoltoMass = mCH4*xCH4 + mCO*xCO + mCO2*xCO2 + mH2*xH2 + mH2O*xH2O + ...
        mN2*xN2 + mO2*xO2;
    
    % Convert J/mol.K * (1 kJ/1000 J) * (mol/g) * (1000g/kg) = kJ/kg.K
    TotalCpVect = CalcCp .*(1/1000).*(1./MoltoMass).*1000;

end