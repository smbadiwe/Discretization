function H2OVisc = IAPWS_Visc(T, rho)

% The viscosity of water vapour is calculated based on "Release on the
% IAPWS Formulation 2008 for the Viscosity of Ordinary Water Substances"
% from the International Association for the Properties of Water and Steam.

% Data taken from:
% Wagner, W., Kretzschmar, H-J. (2008). International Steam Tables (2nd
% Ed.). Berlin, Germany: Springer-Verlag. 

theta1 = T / 647.096; % critical temperature divided by actual temperature
theta2 = 647.096 / T;
delta2 = (rho * 18.02 / 1000) / 322; % actual mass dens. divided by critical density

% Coefficient values for viscosity in the ideal gas limit. 
coeff1 =   [1 0.0167752
            2 0.0220462
            3 0.006366564
            4 -0.00241605];

% Coefficient values for viscosity, adjusting the ideal gas limit calc. 
coeff2 =   [1 0 0 0.520094
            2 0 1 0.0850895
            3 0 2 -1.08374
            4 0 3 -0.289555
            5 1 0 0.222531
            6 1 1 0.999115
            7 1 2 1.88797
            8 1 3 1.26613
            9 1 5 0.120573
            10 2 0 -0.281378
            11 2 1 -0.906851
            12 2 2 -0.772479
            13 2 3 -0.489837
            14 2 4 -0.257040
            15 3 0 0.161913
            16 3 1 0.257399
            17 4 0 -0.0325372
            18 4 3 0.0698452
            19 5 4 0.00872102
            20 6 3 -0.00435673
            21 6 5 -0.000593264];

term1sum = 0;
term2sum = 0;

% Calculate sum for viscosity in the ideal gas limit. 
for i = 1:4
    term1sum = term1sum + coeff1(i,2) * theta1 ^ (1-i);
end

% Calculate the sum for the adjusting factor. 
for i = 1:21
    term2sum = term2sum + coeff2(i,4) * ((delta2 - 1) ^ coeff2(i,2))...
        * ((theta2 ^ -1 - 1) ^ coeff2(i,3));
end

% Calculate the viscosity, in units of 1*10^-6 Pa.s
H2OVisc = ((theta1 ^ 0.5) * ((term1sum) ^ -1)) * (exp(delta2*term2sum));
       
end