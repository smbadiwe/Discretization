function r_CH4 = rate1(P, T, xCH4, xCO2, xH2O, xCO, xH2, vel, rhoM, Acs)

% Akpan et al., 2007 --> Ni // CeO2-ZrO2 catalyst
R = 8.3144598; % m^3*Pa/K/mol, universal gas constant
P_CH4 = xCH4 * P/1000;

% Adapted from original data --> Coefficients provided were giving odd
% results, recorrelated to get better results. 
k_0 = 7.083E11; Ea = 1.499E05; n = 5.690E-01; 

% kg CH4 / kg cat.h
Akpan = (k_0 * exp(-Ea/(R*T)) * P_CH4 ^ n);

% kg CH4 / (kg CH4 / kmol CH4) * (1000 mol / kmol) / (60 min/hr * 60 s/min)
% mol CH4 / kg cat.s
r_CH4 = Akpan / (16.04) * 1000 / (60 * 60);

end




