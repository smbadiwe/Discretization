function Zfactor = PengRobEOS(T, rho, s)

% Zfactor uses the Peng-Robinson Equation of State to calculate the
% compressibility factor (Z factor) for a given gaseous species. 

% Data taken from: 
% Elliott, J., Lira, C. (2012). Introductory Chemical Engineering
% Thermodynamics (2nd Ed.). Upper Saddle River, NJ: Pearson Education Inc.

R = 8.3144598; % m^3*Pa/K/mol, universal gas constant

% Critical temperatures, pressures, and acentric factors for species.
% deg-K, MPa, [no dim.]

PRSpec = [ 1  190.6  4.604  0.011       %CH4
           2  304.2  7.382  0.228       %CO2
           3  647.3  22.12  0.344       %H2O
           4  132.9  3.499  0.066       %CO
           5  33.3   1.297  -0.215      %H2
           6  126.1  3.394  0.040       %N2
           7  154.6  5.043  0.022       %O2
           ];

% Retrieves values for desired species, based on [s] index. 
T_crit = PRSpec(s,2); % deg-K
P_crit = PRSpec(s,3); % MPa
acentric = PRSpec(s,4); % no dim.

% Calculation of coefficients for PR-EOS calculation. 
kappa = 0.37464 + 1.54226 * acentric - 0.26992 * acentric ^ 2;
alpha = (1 + kappa * (1 - sqrt(T ./ T_crit))).^2;
a_c = 0.45723553 * (R ^ 2) * (T_crit ^ 2) / (P_crit * 10^6); 
a = a_c .* alpha; 
b = 0.07779607 * R * T_crit / (P_crit * 10^6);

% Calculation of compressibility factor for desired species. 
Zfactor = 1./(1 - b .* rho) - (a ./ (b .* R .* T)) .* (b .* rho ./ (1 + ...
    2 .* b .* rho - b.^2 .* rho.^2));

end