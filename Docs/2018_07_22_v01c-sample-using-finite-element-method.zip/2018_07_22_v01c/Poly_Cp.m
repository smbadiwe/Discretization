function GasCp = Poly_Cp(T,s)

% Data taken from: 
% Elliott, J., Lira, C. (2012). Introductory Chemical Engineering
% Thermodynamics (2nd Ed.). Upper Saddle River, NJ: Pearson Education Inc.

% CH4, CO2, H2O, CO, H2, N2, O2
Coeff = [   1   19.25   5.21E-02    1.20E-05   -1.13E-08
            2   19.80   7.34E-02   -5.60E-05    1.72E-08
            3   32.24   1.92E-03    1.06E-05   -3.60E-09
            4   30.87  -1.29E-02    2.79E-05   -1.27E-08
            5   27.14   9.27E-03   -1.38E-05    7.65E-09
            6   31.15  -0.01357     2.68E-05   -1.17E-08
            7   28.11  -3.70E-06    1.75E-05   -1.07E-08];

% Calculations are based on an empirical relationship:
% C1 + C2 * T + C3 * T^2 + C4 * T^3
        
% Returns as J/mol.K
GasCp = (Coeff(s,2) + Coeff(s,3).*T + Coeff(s,4).*T.^2 + Coeff(s,5).*T.^3);

end