function TotalDensVect = Mix_DensVect(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2, i)

% The density of a gas mixture is calculated based on the ideal gas law,
% with the compressibility factor for each species calculated at the full
% pressure of the gas, and then all summed together by mole fraction to
% give the mixture's compressibility factor (following Amagat's law). This
% is then combined with ideal gas law to calculate the molar density of the
% gas mixture. Based on mole fractions, the equivalent mass density of the
% gas is also calculated and reported. 

% An initial density is required, since Peng-Robinson uses the gas density
% as an input to calculate the compressibility factor. This inital density
% is simply taken as the mass density of water vapour at the specified
% pressure and temperature. 

    R = 8.3144598; % m^3*Pa/K/mol, universal gas constant
    rhoSTP = 44.59; % mol/m^3, for water vapour - initial guess.
    rho = rhoSTP .* ((P./101315).*(273.15./T)); % Guess using IGL
    rhoCheck = rho; % used to iterate density. 
    error = 1;

    % Setting up a matrix to store pure component properties.
    % Species mole fraction, species compressibility factor. 
    PureDens = zeros(i,7,2);
    
    PureDens(:,1,1) = xCH4;
    PureDens(:,2,1) = xCO2;
    PureDens(:,3,1) = xCO;
    PureDens(:,4,1) = xH2O;
    PureDens(:,5,1) = xH2;
    PureDens(:,6,1) = xN2;
    PureDens(:,7,1) = xO2;
    
    % Calculation iterates until the error threshold is satisfied. 
    while error > 10E-6
    
    % Individual compressibility factors are calculated. 
    PureDens(:,1,2) = PengRobEOSVect(T,rho,1);
    PureDens(:,2,2) = PengRobEOSVect(T,rho,2);
    PureDens(:,3,2) = PengRobEOSVect(T,rho,3);
    PureDens(:,4,2) = PengRobEOSVect(T,rho,4);
    PureDens(:,5,2) = PengRobEOSVect(T,rho,5);
    PureDens(:,6,2) = PengRobEOSVect(T,rho,6);
    PureDens(:,7,2) = PengRobEOSVect(T,rho,7);
    
    % Amagat's law calculates the mixture compressibility factor.
    PureDens(:,:,2) = PureDens(:,:,2) .* PureDens(:,:,1);
    Z_mix = PureDens(:,:,2)*ones(7,1);
    
    % Ideal gas law, n/V = rho = R/ZRT.
    rho = P ./ (Z_mix .* R .* T); %mol/m^3
    
    % Error is calculated. 
    error = sum(abs(1-rho./rhoCheck));
    rhoCheck = rho;
    
    end
    
    % Getting mean mass density (g/mol) for gas mixture. 
    mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
    mN2 = 28.02; mO2 = 32.00;
    MoltoMass = mCH4*xCH4 + mCO*xCO + mCO2*xCO2 + mH2*xH2 + mH2O*xH2O + ...
        mN2*xN2 + mO2*xO2;
    
    % mol/m^3 * kg/kmol * (kmol/1000mol) = kg/m^3
    TotalDensVect = rho .* (MoltoMass/1000); 

end