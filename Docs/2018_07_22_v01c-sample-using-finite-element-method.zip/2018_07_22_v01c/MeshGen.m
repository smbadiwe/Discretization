
% Generation of a one-dimensional uniform mesh. Follows a cell-centered
% finite volume (or finite difference) mesh. Cell centers and face centers
% are established for a given length of reactor. 

% NOTE: Eventually, this will be replaced with a 2D unstructured mesh...
% just working on the framework for the overall reactor model. 


d_t = 0.10; Acs = pi*(d_t/2)^2;
d_p = 0.00037;
eps = 0.38 + 0.073 * (1+(((d_t/d_p-2)^2)/((d_t/d_p)^2)));
u_z = 0.0361;

L = 1; % Length of the reactor, in meters.
t = 20; % Time of response, in seconds.

cellnum = 50; dz = L/cellnum;
timestep = 200; dt = t/timestep;
facenum = cellnum + 1;
MeshFace = zeros(facenum,2); 
MeshCell = zeros(cellnum,2);

MeshFace(1,1) = 1; MeshFace(1,2) = 0;

for i = 1:cellnum
    
    MeshFace(1+i,1) = 1+i;
    MeshFace(1+i,2) = MeshFace(i,2) + L / cellnum;
    MeshCell(i,1) = i;
    MeshCell(i,2) = MeshFace(i,2) + (MeshFace(1+i,2) - MeshFace(i,2))/2;
    
end
