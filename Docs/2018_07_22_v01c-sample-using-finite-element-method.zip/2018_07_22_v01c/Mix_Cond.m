function TotalCond = Mix_Cond(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2)

% Multicomponent gas mixture conductivity is based on the relation of 
% Mason and Saxena, which can be reviewed in Transport Phenomena, 2nd Ed. 
% (Bird et al., 2002)

    % Setting up a matrix to store pure component properties.
    PureCond = zeros(7,4);
    
    % Setting molar masses of each species. 
    PureCond(1,3) = 16.04;  % CH4
    PureCond(2,3) = 44.02;  % CO2
    PureCond(3,3) = 18.03;  % H2O  
    PureCond(4,3) = 28.01;  % CO
    PureCond(5,3) = 2.02;   % H2
    PureCond(6,3) = 28.02;  % N2
    PureCond(7,3) = 32.00;  % O2
    
    PureCond(1,4) = xCH4;
    PureCond(2,4) = xCO2;
    PureCond(3,4) = xH2O;
    PureCond(4,4) = xCO;
    PureCond(5,4) = xH2;
    PureCond(6,4) = xN2;
    PureCond(7,4) = xO2;
    
    PureCond(1,2) = Poly_Cond(T,1); %CH4
    PureCond(2,2) = Poly_Cond(T,2); %CO2
    PureCond(4,2) = Poly_Cond(T,3); %CO --> H2O Calc'd from IAPWS.
    PureCond(5,2) = Poly_Cond(T,4); %H2
    PureCond(6,2) = Poly_Cond(T,5); %N2
    PureCond(7,2) = Poly_Cond(T,6); %O2
    
    % Water density at standard temperature & pressure (273.15 K, 101.315 kPa)
    
    R = 8.3144598; % m^3*Pa/K/mol, universal gas constant
    rhoSTP = 44.59; % mol/m^3
    rho = rhoSTP * ((P/101315)*(273.15/T)); % Guess using IGL

    Z = PengRobEOS(T, rho, 5);
    rho = (P) / (Z * R * T); % mol/m^3, calc'd with Peng Robinson.
    PureCond(3,2) = IAPWS_Cond(T, rho); % W/m.K
    
    % Initialize variables
    BinCond = 0;
    SumCond = 0;
    
    % In the expression from Mason & Saxena, the thermal conductivities of
    % each gas species are calculated, and are then summed up into the
    % total gas mixture. For example, for a CH4-CO2-H2O feed mixture, the
    % viscosity would be the sum of the binary mixture viscosities for
    % CH4-CO2, CH4-H2O, and CO2-H2O. Mason & Saxena are taken as a
    % semi-empirical method.
    
    % A number of alternative mixed gas methods can be found in The
    % Properties of Gases and Liquids, commonly derived from either
    % Chapman-Enskog theory or Corresponding States theory. 
    
    for i = 1:7                 % Summation of binary thermal conductivities
        sumden = 0;
        for j = 1:7             % Calculation of each binary conductivity
            if i == j
                BinCond = 1;    % Will just be unity when considering own species
            else
                BinCond = (1/sqrt(8)) * ((1 + PureCond(i,3)/PureCond(j,3)) ^ (-1/2)) * ...
                    (1 + ((PureCond(i,2)/PureCond(j,2))^(1/2))*((PureCond(j,3)/PureCond(i,3))^(1/4)));
            end
            sumden = sumden + PureCond(j,4) * BinCond;
        end
        SumCond = SumCond + PureCond(i,4) * PureCond(i,2) / sumden;
    end
    
    % W/m.K --> J/m.s.k to kJ/m.s.K
    TotalCond = SumCond/1000;
    
end