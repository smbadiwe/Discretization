% Using EOS to define the species density at each cell and face center.
% 2018/07/22 (MTF) - Note that this has now been vectorized. 

k=k;

i = cellnum;
MeshPress(2:i,k) = (MatrixPress(1:i-1,k)+MatrixPress(2:i,k))/2;
MeshTemp(2:i,k) = (MatrixTemp(1:i-1,k)+MatrixTemp(2:i,k))/2;
MeshFrac_CH4(2:i,k) = (MatrixFrac_CH4(1:i-1,k)+MatrixFrac_CH4(2:i,k))/2;
MeshFrac_CO2(2:i,k) = (MatrixFrac_CO2(1:i-1,k)+MatrixFrac_CO2(2:i,k))/2;
MeshFrac_H2O(2:i,k) = (MatrixFrac_H2O(1:i-1,k)+MatrixFrac_H2O(2:i,k))/2;
MeshFrac_CO(2:i,k) = (MatrixFrac_CO(1:i-1,k)+MatrixFrac_CO(2:i,k))/2;
MeshFrac_H2(2:i,k) = (MatrixFrac_H2(1:i-1,k)+MatrixFrac_H2(2:i,k))/2;
MeshFrac_N2(2:i,k) = (MatrixFrac_N2(1:i-1,k)+MatrixFrac_N2(2:i,k))/2;
MeshFrac_O2(2:i,k) = (MatrixFrac_O2(1:i-1,k)+MatrixFrac_O2(2:i,k))/2;

i = facenum; % This is not preferred, btw. Fix this. 
MeshPress(i,k) = MatrixPress(i-1,k);
MeshTemp(i,k) = MatrixTemp(i-1,k);
MeshFrac_CH4(i,k) = MatrixFrac_CH4(i-1,k);
MeshFrac_CO2(i,k) = MatrixFrac_CO2(i-1,k);
MeshFrac_H2O(i,k) = MatrixFrac_H2O(i-1,k);
MeshFrac_CO(i,k) = MatrixFrac_CO(i-1,k);
MeshFrac_H2(i,k) = MatrixFrac_H2(i-1,k);
MeshFrac_N2(i,k) = MatrixFrac_N2(i-1,k);
MeshFrac_O2(i,k) = MatrixFrac_O2(i-1,k);

i = cellnum;
P = MatrixPress(1:i,k); T = MatrixTemp(1:i,k); xCH4 = MatrixFrac_CH4(1:i,k);
xCO2 = MatrixFrac_CO2(1:i,k); xH2O = MatrixFrac_H2O(1:i,k);
xCO = MatrixFrac_CO(1:i,k); xH2 = MatrixFrac_H2(1:i,k); 
xN2 = MatrixFrac_N2(1:i,k); xO2 = MatrixFrac_O2(1:i,k); 

MatrixDens(1:i,k) = Mix_DensVect(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2, i);
Matrix_cond(1:i,k) = Mix_CondVect(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2, i);
MatrixCp(1:i,k) = Mix_CpVect(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2,i);
Matrix_Mu(1:i,k) = Mix_ViscVect(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2, i);

% Getting mean mass density (g/mol) for gas mixture. 
mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
mN2 = 28.02; mO2 = 32.00;
MoltoMass = mCH4*xCH4 + mCO*xCO + mCO2*xCO2 + mH2*xH2 + mH2O*xH2O + ...
    mN2*xN2 + mO2*xO2;

% mol/m^3 = kg/m^3 / (g/mol *(1 kg/1000g)
MatrixDensM(1:i,k) = MatrixDens(1:i,k) ./ (MoltoMass/1000);

i = facenum;

P = MeshPress(1:i,k); T = MeshTemp(1:i,k); xCH4 = MeshFrac_CH4(1:i,k);
xCO2 = MeshFrac_CO2(1:i,k); xH2O = MeshFrac_H2O(1:i,k);
xCO = MeshFrac_CO(1:i,k); xH2 = MeshFrac_H2(1:i,k); 
xN2 = MeshFrac_N2(1:i,k); xO2 = MeshFrac_O2(1:i,k); 
diff = Mix_MolDiffVect(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2,i);

Mesh_mu(1:i,k) = Mix_ViscVect(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2,i);
Mesh_cond(1:i,k) = Mix_CondVect(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2,i);
MeshCp(1:i,k) = Mix_CpVect(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2,i);
MeshDens(1:i,k) = Mix_DensVect(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2,i);

Mesh_DCH4(1:i,k) = diff(1:i,1);
Mesh_DCO2(1:i,k) = diff(1:i,2);
Mesh_DH2O(1:i,k) = diff(1:i,3);
Mesh_DCO(1:i,k) = diff(1:i,4);
Mesh_DH2(1:i,k) = diff(1:i,5);
Mesh_DN2(1:i,k) = diff(1:i,6);
Mesh_DO2(1:i,k) = diff(1:i,7);

% Getting mean mass density (g/mol) for gas mixture. 
mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
mN2 = 28.02; mO2 = 32.00;
MoltoMass = mCH4*xCH4 + mCO*xCO + mCO2*xCO2 + mH2*xH2 + mH2O*xH2O + ...
    mN2*xN2 + mO2*xO2;

% mol/m^3 = kg/m^3 / (g/mol *(1 kg/1000g)
MeshDensM(1:i,k) = MeshDens(1:i,k) ./ (MoltoMass./1000);

