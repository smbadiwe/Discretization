
tic

MeshGen
RXR_Init
CalcPressTemp

toc
%{
%{figure(1);
plot(MeshCell(:,2),MatrixPress(:,2),'r--o',...
    MeshCell(:,2),MatrixPress(:,timestep*(1/4)),'b--o',...
    MeshCell(:,2),MatrixPress(:,timestep*(1)),'k--o');
title('Pressure Profile Along Axis'); 
ylabel('Pressure, Pa'); xlabel('Axial Position, m');
ytickformat('%.2f')

figure(2);
plot(MeshCell(:,2),MatrixTemp(:,2),'r--o',...
    MeshCell(:,2),MatrixTemp(:,timestep*(1/4)),'b--o',...
    MeshCell(:,2),MatrixTemp(:,timestep*(1)),'k--o');
title('Temperature Profile Along Axis'); 
ylabel('Temperature, K'); xlabel('Axial Position, m');
ytickformat('%.1f')

%}

%{
for i = 1:timestep
plot(MeshCell(:,2),MatrixTemp(:,i),'r--o')
title('Temperature Profile Along Axis'); 
ylabel('Temperature, K'); xlabel('Axial Position, m'); pause;
end

for i = 1:timestep
plot(MeshCell(:,2),MatrixDens(:,i),'k--o');
title('Gas Phase Density Along Axis'); 
ylabel('Density, Kg/m^3'); xlabel('Axial Position, m'); pause;
end

 for i = 1:timestep
plot(MeshCell(:,2),MatrixPress(:,i),'b--o');
title('Pressure Profile Along Axis'); 
ylabel('Pressure, Pa'); xlabel('Axial Position, m'); pause(0.05);
end

for i = 1:timestep
plot(MeshCell(:,2),MatrixFrac_ALL(:,i), MeshCell(:,2),MatrixFrac_CH4(:,i),...
MeshCell(:,2),MatrixFrac_CO2(:,i), MeshCell(:,2),MatrixFrac_H2O(:,i),...
MeshCell(:,2),MatrixFrac_CO(:,i), MeshCell(:,2),MatrixFrac_H2(:,i),...
MeshCell(:,2),MatrixFrac_N2(:,i), MeshCell(:,2),MatrixFrac_O2(:,i));
title('Mass Fraction Along Axis'); 
legend('ALL','CH4','CO2','H2O','CO','H2','N2','O2');
ylabel('Mass Frac, %'); xlabel('Axial Position, m'); pause(0.05);
end

for i = 1:timestep
plot(MeshCell(:,2),MatrixFrac_ALL(:,i),...
MeshCell(:,2),MatrixFracM_ALL(:,i)); pause(0.05);
end

for i = 1:timestep
plot(MeshCell(:,2),MatrixFracM_CH4(:,i),...
MeshCell(:,2),MatrixFracM_CO2(:,i), MeshCell(:,2),MatrixFracM_H2O(:,i),...
MeshCell(:,2),MatrixFracM_CO(:,i), MeshCell(:,2),MatrixFracM_H2(:,i),...
MeshCell(:,2),MatrixFracM_N2(:,i), MeshCell(:,2),MatrixFracM_O2(:,i));
title('Mole Fraction Along Axis'); 
legend('CH4','CO2','H2O','CO','H2','N2','O2','location','southoutside','orientation','horizontal');
ylabel('Mole Frac, %'); xlabel('Axial Position, m'); pause(0.05);
end
%}