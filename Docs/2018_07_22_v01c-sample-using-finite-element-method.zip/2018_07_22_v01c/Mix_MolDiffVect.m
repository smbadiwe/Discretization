function TotalDiffVect = Mix_MolDiffVect(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2, i)

% Binary diffusion coefficients are calculated based on the semi-empirical
% correlation presented by Fuller et al., which makes use of atomic
% volumes. The multicomponent gas diffusivity is then computed from the
% Stefan-Maxwell equation. 

% Useful references are Geankoplis, and Bird et al.

    PureDiff = zeros(i,7,9);

    PureDiff(:,1,1) = xCH4;
    PureDiff(:,2,1) = xCO2;
    PureDiff(:,3,1) = xH2O;
    PureDiff(:,4,1) = xCO;
    PureDiff(:,5,1) = xH2;
    PureDiff(:,6,1) = xN2;
    PureDiff(:,7,1) = xO2;
    
    % Setting molar masses of each species. 
    PureDiff(:,1,2) = 16.04;
    PureDiff(:,2,2) = 44.02;
    PureDiff(:,3,2) = 18.03;
    PureDiff(:,4,2) = 28.01;
    PureDiff(:,5,2) = 2.02;
    PureDiff(:,6,2) = 28.02;
    PureDiff(:,7,2) = 32.00;
    
    % Setting molar diffusion volumes. 
    PureDiff(:,1,3) = 24.4;
    PureDiff(:,2,3) = 26.9;
    PureDiff(:,3,3) = 12.7;
    PureDiff(:,4,3) = 18.9;
    PureDiff(:,5,3) = 7.07;
    PureDiff(:,6,3) = 17.9;
    PureDiff(:,7,3) = 16.6;
    
    for i = 1:7 % Incorporate binary diffusion into gas mixture diffusion.
    for j = 1:7 % Calculate binary diffusion coefficient.
        
        if i == j
            PureDiff(:,i,j+4)=0;
        else
            Ma = PureDiff(:,i,2); Mb = PureDiff(:,j,2);
            Va = PureDiff(:,i,3); Vb = PureDiff(:,j,3);
            
            PureDiff(:,i,j+4) = (10E-5).*(T.^1.75).*(1./Ma + 1./Mb).^0.5./...
                P.*(Va.^(1/3)+Vb.^(1/3));
            PureDiff(:,i,4) = PureDiff(:,i,4) + PureDiff(j,1)./PureDiff(:,i,j+4); 
        end
    end
    PureDiff(:,i,4) = (1 - PureDiff(:,i,1))./PureDiff(:,i,4);
    end

    % Returns all calculated diffusivities as a vector. 
    % Units of mol/m^2.s
    TotalDiffVect = PureDiff(:,:,4); 
    
end