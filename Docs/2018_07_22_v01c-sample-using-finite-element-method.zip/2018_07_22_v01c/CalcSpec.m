
MatrixFrac_CH4LHS = zeros(cellnum,cellnum);
MatrixFrac_CO2LHS = zeros(cellnum,cellnum);
MatrixFrac_H2OLHS = zeros(cellnum,cellnum); 
MatrixFrac_COLHS = zeros(cellnum,cellnum);
MatrixFrac_H2LHS = zeros(cellnum,cellnum);
MatrixFrac_CH4RHS = zeros(cellnum,1);
MatrixFrac_CO2RHS = zeros(cellnum,1);
MatrixFrac_H2ORHS = zeros(cellnum,1);
MatrixFrac_CORHS = zeros(cellnum,1);
MatrixFrac_H2RHS = zeros(cellnum,1);

k=k;

for i = 1:cellnum
    
    P = MatrixPress(i,k-1); T = MatrixTemp(i,k-1); xCH4 = MatrixFrac_CH4(i,k-1);
    xCO2 = MatrixFrac_CO2(i,k-1); xH2O = MatrixFrac_H2O(i,k-1);
    xCO = MatrixFrac_CO(i,k-1); xH2 = MatrixFrac_H2(i,k-1); 
    xN2 = MatrixFrac_N2(i,k-1); xO2 = MatrixFrac_O2(i,k-1); 
    
    xMCH4 = MatrixFracM_CH4(i,k-1);
    xMCO2 = MatrixFracM_CO2(i,k-1); xMH2O = MatrixFracM_H2O(i,k-1);
    xMCO = MatrixFracM_CO(i,k-1); xMH2 = MatrixFracM_H2(i,k-1); 
    xMN2 = MatrixFracM_N2(i,k-1); xMO2 = MatrixFracM_O2(i,k-1); 

    uz1 = MeshVel(i,k-1); uz2 = MeshVel(i+1,k-1); uz = MatrixVel(i,k-1);
    rho1 = MeshDens(i,k-1); rho2 = MeshDens(i+1,k-1); rho = MatrixDens(i,k-1);
    mu1 = Mesh_mu(i,k-1); mu2 = Mesh_mu(i+1,k-1); mu = Matrix_Mu(i,k-1);
    Cp1 = MeshCp(i,k-1); Cp2 = MeshCp(i+1,k-1); Cp = MatrixCp(i,k-1);
    cond1 = Mesh_cond(i,k-1); cond2 = Mesh_cond(i+1,k-1); cond = Matrix_cond(i,k-1);
    
    mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
    mN2 = 28.02; mO2 = 32.00;
    M2m = mCH4*xCH4 + mCO*xCO + mCO2*xCO2 + mH2*xH2 + mH2O*xH2O + ...
        mN2*xN2 + mO2*xO2; % Mole to Mass
    
    MatrixSMR1 = MatrixRXN(i,k-1,1); rxn1 = MatrixSMR1*0;
    MatrixSMR2 = MatrixRXN(i,k-1,2); rxn2 = MatrixSMR2*0;
    MatrixSMR3 = MatrixRXN(i,k-1,3); rxn3 = MatrixSMR3*0;
    
    % Finding species reaction rates, based on stoichiometric equations.
    rxnCH4 = -rxn1-rxn3; rxnCO2 = rxn2+rxn3; rxnH2O = -rxn1-2*rxn3;
    rxnCO = rxn1-rxn2; rxnH2 = 3*rxn1+rxn2+4*rxn3;
    
    D = 0;%10^-6; % Placeholder for diffusivity --> need this by individual species. 

    DCH4_1 = D; DCH4_2 = D; 
    DCO2_1 = D; DCO2_2 = D; 
    DH2O_1 = D; DH2O_2 = D; 
    DCO_1 = D; DCO_2 = D; 
    DH2_1 = D; DH2_2 = D; 

    %Note: molar weights are adjusted to show Kg/mol from g/mol.
    if i == 1
        MatrixFrac_CH4LHS(i,i) = rho*(dz/dt)+rho2*uz2+DCH4_2*rho2/dz+DCH4_1*rho1/(dz/2);
        MatrixFrac_CH4LHS(i,i+1) = -DCH4_2*rho2/dz;
        MatrixFrac_CH4RHS(i,1) = rho*xCH4*(dz/dt)+(rxnCH4*rhobed*(mCH4/1000))*dz+...
            (rho1*uz1+DCH4_1*rho1/(dz/2))*xCH4_in;
        
        MatrixFrac_CO2LHS(i,i) = rho*(dz/dt)+rho2*uz2+DCO2_2*rho2/dz+DCO2_1*rho1/(dz/2);
        MatrixFrac_CO2LHS(i,i+1) = -DCO2_2*rho2/dz;
        MatrixFrac_CO2RHS(i,1) = rho*xCO2*(dz/dt)+(rxnCO2*rhobed*(mCO2/1000))*dz+...
            (rho1*uz1+DCO2_1*rho1/(dz/2))*xCO2_in;

        MatrixFrac_H2OLHS(i,i) = rho*(dz/dt)+rho2*uz2+DH2O_2*rho2/dz+DH2O_1*rho1/(dz/2);
        MatrixFrac_H2OLHS(i,i+1) = -DH2O_2*rho2/dz;
        MatrixFrac_H2ORHS(i,1) = rho*xH2O*(dz/dt)+(rxnH2O*rhobed*(mH2O/1000))*dz+...
            (rho1*uz1+DH2O_1*rho1/(dz/2))*xH2O_in;

        MatrixFrac_COLHS(i,i) = rho*(dz/dt)+rho2*uz2+DCO_2*rho2/dz+DCO_1*rho1/(dz/2);
        MatrixFrac_COLHS(i,i+1) = -DCO_2*rho2/dz;
        MatrixFrac_CORHS(i,1) = rho*xCO*(dz/dt)+(rxnCO*rhobed*(mCO/1000))*dz+...
            (rho1*uz1+DCO_1*rho1/(dz/2))*xCO_in;

        MatrixFrac_H2LHS(i,i) = rho*(dz/dt)+rho2*uz2+DH2_2*rho2/dz+DH2_1*rho1/(dz/2);
        MatrixFrac_H2LHS(i,i+1) = -DH2_2*rho2/dz;
        MatrixFrac_H2RHS(i,1) = rho*xH2*(dz/dt)+(rxnH2*rhobed*(mH2/1000))*dz+...
            (rho1*uz1+DH2_1*rho1/(dz/2))*xH2_in;
    
    elseif i == cellnum
        MatrixFrac_CH4LHS(i,i-1) = -rho1*uz1-DCH4_1*rho1/dz;
        MatrixFrac_CH4LHS(i,i) = rho*(dz/dt)+rho2*uz2+DH2_1*rho1/dz;
        MatrixFrac_CH4RHS(i,1) = rho*xCH4*(dz/dt)+(rxnCH4*rhobed*(mCH4/1000))*dz;
        
        MatrixFrac_CO2LHS(i,i-1) = -rho1*uz1-DCO2_1*rho1/dz;
        MatrixFrac_CO2LHS(i,i) = rho*(dz/dt)+rho2*uz2+DH2_1*rho1/dz;
        MatrixFrac_CO2RHS(i,1) = rho*xCO2*(dz/dt)+(rxnCO2*rhobed*(mCO2/1000))*dz;

        MatrixFrac_H2OLHS(i,i-1) = -rho1*uz1-DH2O_1*rho1/dz;
        MatrixFrac_H2OLHS(i,i) = rho*(dz/dt)+rho2*uz2+DH2_1*rho1/dz;
        MatrixFrac_H2ORHS(i,1) = rho*xH2O*(dz/dt)+(rxnH2O*rhobed*(mH2O/1000))*dz;

        MatrixFrac_COLHS(i,i-1) = -rho1*uz1-DCO_1*rho1/dz;
        MatrixFrac_COLHS(i,i) = rho*(dz/dt)+rho2*uz2+DH2_1*rho1/dz;
        MatrixFrac_CORHS(i,1) = rho*xCO*(dz/dt)+(rxnCO*rhobed*(mCO/1000))*dz;

        MatrixFrac_H2LHS(i,i-1) = -rho1*uz1-DH2_1*rho1/dz;
        MatrixFrac_H2LHS(i,i) = rho*(dz/dt)+rho2*uz2+DH2_1*rho1/dz;
        MatrixFrac_H2RHS(i,1) = rho*xH2*(dz/dt)+(rxnH2*rhobed*(mH2/1000))*dz;
        
    else
        MatrixFrac_CH4LHS(i,i-1) = -rho1*uz1-DCH4_1*rho1/dz;
        MatrixFrac_CH4LHS(i,i) = rho*(dz/dt)+rho2*uz2+DCH4_2*rho2/dz+DCH4_1*rho1/dz;
        MatrixFrac_CH4LHS(i,i+1) = -DCH4_2*rho2/dz;
        MatrixFrac_CH4RHS(i,1) = rho*xCH4*(dz/dt)+(rxnCH4*rhobed*(mCH4/1000))*dz;
        
        MatrixFrac_CO2LHS(i,i-1) = -rho1*uz1-DCO2_1*rho1/dz;
        MatrixFrac_CO2LHS(i,i) = rho*(dz/dt)+rho2*uz2+DCO2_2*rho2/dz+DCO2_1*rho1/dz;
        MatrixFrac_CO2LHS(i,i+1) = -DCO2_2*rho2/dz;
        MatrixFrac_CO2RHS(i,1) = rho*xCO2*(dz/dt)+(rxnCO2*rhobed*(mCO2/1000))*dz;

        MatrixFrac_H2OLHS(i,i-1) = -rho1*uz1-DH2O_1*rho1/dz;
        MatrixFrac_H2OLHS(i,i) = rho*(dz/dt)+rho2*uz2+DH2O_2*rho2/dz+DH2O_1*rho1/dz;
        MatrixFrac_H2OLHS(i,i+1) = -DH2O_2*rho2/dz;
        MatrixFrac_H2ORHS(i,1) = rho*xH2O*(dz/dt)+(rxnH2O*rhobed*(mH2O/1000))*dz;

        MatrixFrac_COLHS(i,i-1) = -rho1*uz1-DCO_1*rho1/dz;
        MatrixFrac_COLHS(i,i) = rho*(dz/dt)+rho2*uz2+DCO_2*rho2/dz+DCO_1*rho1/dz;
        MatrixFrac_COLHS(i,i+1) = -DCO_2*rho2/dz;
        MatrixFrac_CORHS(i,1) = rho*xCO*(dz/dt)+(rxnCO*rhobed*(mCO/1000))*dz;

        MatrixFrac_H2LHS(i,i-1) = -rho1*uz1-DH2_1*rho1/dz;
        MatrixFrac_H2LHS(i,i) = rho*(dz/dt)+rho2*uz2+DH2_2*rho2/dz+DH2_1*rho1/dz;
        MatrixFrac_H2LHS(i,i+1) = -DH2_2*rho2/dz;
        MatrixFrac_H2RHS(i,1) = rho*xH2*(dz/dt)+(rxnH2*rhobed*(mH2/1000))*dz;

    end
    
end

    MatrixSoln_CH4 = sparse(MatrixFrac_CH4LHS\MatrixFrac_CH4RHS);
    MatrixSoln_CO2 = sparse(MatrixFrac_CO2LHS\MatrixFrac_CO2RHS); 
    MatrixSoln_H2O = sparse(MatrixFrac_H2OLHS\MatrixFrac_H2ORHS); 
    MatrixSoln_CO = sparse(MatrixFrac_COLHS\MatrixFrac_CORHS); 
    MatrixSoln_H2 = sparse(MatrixFrac_H2LHS\MatrixFrac_H2RHS); 
    
    MatrixFrac_CH4(:,k) = MatrixSoln_CH4(1:cellnum,1);
    MatrixFrac_CO2(:,k) = MatrixSoln_CO2(1:cellnum,1); 
    MatrixFrac_H2O(:,k) = MatrixSoln_H2O(1:cellnum,1); 
    MatrixFrac_CO(:,k) = MatrixSoln_CO(1:cellnum,1); 
    MatrixFrac_H2(:,k) = MatrixSoln_H2(1:cellnum,1); 
    MatrixFrac_ALL(:,k) = MatrixFrac_CH4(:,k) + MatrixFrac_CO2(:,k) + ...
        MatrixFrac_H2O(:,k) + MatrixFrac_CO(:,k) + MatrixFrac_H2(:,k) + ...
        MatrixFrac_N2(:,k) + MatrixFrac_O2(:,k);
    
    MasstoMol = MatrixFrac_CH4(:,k)./mCH4 + MatrixFrac_CO2(:,k)./mCO2 + ...
        MatrixFrac_H2O(:,k)./mH2O + MatrixFrac_CO(:,k)./mCO + ...
        MatrixFrac_H2(:,k)./mH2 + MatrixFrac_N2(:,k)./mN2 + ...
        MatrixFrac_O2(:,k)./mO2; MoltoMass = 1./MasstoMol;
    
    MatrixFracM_CH4(:,k) = MatrixFrac_CH4(:,k)./(mCH4./MoltoMass);
    MatrixFracM_CO2(:,k) = MatrixFrac_CO2(:,k)./(mCO2./MoltoMass); 
    MatrixFracM_H2O(:,k) = MatrixFrac_H2O(:,k)./(mH2O./MoltoMass); 
    MatrixFracM_CO(:,k) = MatrixFrac_CO(:,k)./(mCO./MoltoMass); 
    MatrixFracM_H2(:,k) = MatrixFrac_H2(:,k)./(mH2./MoltoMass); 
    MatrixFracM_N2(:,k) = MatrixFrac_N2(:,k)./(mN2./MoltoMass); 
    MatrixFracM_O2(:,k) = MatrixFrac_O2(:,k)./(mO2./MoltoMass); 
    MatrixFracM_ALL(:,k) = MatrixFracM_CH4(:,k) + MatrixFracM_CO2(:,k) + ...
        MatrixFracM_H2O(:,k) + MatrixFracM_CO(:,k) + MatrixFracM_H2(:,k) + ...
        MatrixFracM_N2(:,k) + MatrixFracM_O2(:,k);
    
    
    P = MatrixPress(:,k); T = MatrixTemp(:,k); xMCH4 = MatrixFracM_CH4(:,k);
    xMCO2 = MatrixFracM_CO2(:,k); xMH2O = MatrixFracM_H2O(:,k);
    xMCO = MatrixFracM_CO(:,k); xMH2 = MatrixFracM_H2(:,k); 
    xMN2 = MatrixFracM_N2(:,k); xMO2 = MatrixFracM_O2(:,k); 
    
    MatrixRXN(1:i,k,:) = RXNCalcVect(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2, xMN2, xMO2, i);
    