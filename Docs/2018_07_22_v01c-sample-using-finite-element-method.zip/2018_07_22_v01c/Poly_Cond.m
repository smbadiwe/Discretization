function GasCond = Poly_Cond(T,s)

% Coefficient Ordering: CH4, CO2-1, CO2-2, CO, H2-1, H2-2, N2, O2-1, O2-2
% H2O thermal conductivity covered by IAPWS_Visc.

% Data taken from: 
% Rohsenow, W., Hartnett, J., Cho, Y. (1998). Handbook of Heat Transfer
% (3rd Ed). New York, NY: The McGraw-Hill Companies, Inc. 

Coeff = [   1 -1.34015E-02   3.66307E-04  -1.82249E-06   5.93988E-09  -9.14055E-12   6.78969E-15   -1.95049E-18
            2  2.97149E-03  -1.33472E-05   3.14444E-07  -4.75106E-10   2.68500E-13   0             0
            3  6.08538E-02  -3.63680E-04   1.01344E-06  -9.70424E-10   3.27864E-13   0             0
            4 -7.41704E-04   9.87435E-05  -3.77511E-08  -1.99334E-11   3.65528E-14  -1.24272E-17   0
            5  2.00971E-02   3.23462E-04   2.16372E-06  -6.49151E-09   5.52408E-12   0             0
            6  1.08311E-01   2.21164E-04   2.26381E-07  -1.74259E-10   4.64686E-14   0             0
            7 -1.52318E-03   1.18880E-04  -1.20928E-07   1.15568E-10  -6.36537E-14   1.47167E-17   0
            8 -7.67278E-04   1.03560E-04  -4.62034E-08   1.51980E-11  0              0             0
            9 -1.86545E-01   7.05649E-04  -7.71025E-07   4.02144E-10  -7.84908E-14   0             0];

% Individual gas viscosities are calculated from a polynomial function: 
% C1 * T + C2 * T^2 + C3 * T^3 + C4 * T^4 + C5 ^ T^5 + C6 * T^6. 

% These are entirely empirical equations. An alternative source for
% empirical relations can be found in Perry's Chemical Engineering
% Handbook.

% Other methods are discussed in The Properties of Gases and Liquids.

% Thermal conductivities are returned in units of W/m.K
        
switch s
    
    case 1 % CH4
        GasCond = Coeff(1,2) + Coeff(1,3) * T + Coeff(1,4) * T^2 + ...
            Coeff(1,5) * T^3 + Coeff(1,6) * T^4 + Coeff(1,7) * T^5 + ...
            Coeff(1,8) * T^6;
    case 2 % CO2
        if T < 600 % Temperature limit on correlation @ 600K
            GasCond = Coeff(2,2) + Coeff(2,3) * T + Coeff(2,4) * T^2 + ...
                Coeff(2,5) * T^3 + Coeff(2,6) * T^4 + Coeff(2,7) * T^5 + ...
                Coeff(2,8) * T^6;
        else
            GasCond = Coeff(3,2) + Coeff(3,3) * T + Coeff(3,4) * T^2 + ...
                Coeff(3,5) * T^3 + Coeff(3,6) * T^4 + Coeff(3,7) * T^5 + ...
                Coeff(3,8) * T^6;
        end
    case 3 % CO
        GasCond = Coeff(4,2) + Coeff(4,3) * T + Coeff(4,4) * T^2 + ...
            Coeff(4,5) * T^3 + Coeff(4,6) * T^4 + Coeff(4,7) * T^5 + ...
            Coeff(4,8) * T^6;
    case 4 % H2
        if T < 500 % Temperature limit on correlation @ 500K
            GasCond = Coeff(5,2) + Coeff(5,3) * T + Coeff(5,4) * T^2 + ...
                Coeff(5,5) * T^3 + Coeff(5,6) * T^4 + Coeff(5,7) * T^5 + ...
                Coeff(5,8) * T^6;
        else
            GasCond = Coeff(6,2) + Coeff(6,3) * T + Coeff(6,4) * T^2 + ...
                Coeff(6,5) * T^3 + Coeff(6,6) * T^4 + Coeff(6,7) * T^5 + ...
                Coeff(6,8) * T^6;
        end
    case 5 % N2
        GasCond = Coeff(7,2) + Coeff(7,3) * T + Coeff(7,4) * T^2 + ...
            Coeff(7,5) * T^3 + Coeff(7,6) * T^4 + Coeff(7,7) * T^5 + ...
            Coeff(7,8) * T^6;
    case 6 % O2
        if T < 1000 % Temperature limit on correlation @ 1000K
            GasCond = Coeff(8,2) + Coeff(8,3) * T + Coeff(8,4) * T^2 + ...
                Coeff(8,5) * T^3 + Coeff(8,6) * T^4 + Coeff(8,7) * T^5 + ...
                Coeff(8,8) * T^6;
        else
            GasCond = Coeff(9,2) + Coeff(9,3) * T + Coeff(9,4) * T^2 + ...
                Coeff(9,5) * T^3 + Coeff(9,6) * T^4 + Coeff(9,7) * T^5 + ...
                Coeff(9,8) * T^6;
        end
        
end

end