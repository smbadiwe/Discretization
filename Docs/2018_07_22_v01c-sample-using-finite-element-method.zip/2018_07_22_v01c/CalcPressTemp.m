R = 8.3144598; % m^3*Pa/K/mol, universal gas constant

MatrixMassLHS = (zeros(cellnum,cellnum*2));
MatrixMassRHS = (zeros(cellnum,1));
MatrixHeatLHS = (zeros(cellnum,cellnum*2));
MatrixHeatRHS = (zeros(cellnum,1));

for k = 2:timestep
for i = 1:cellnum
   
    P = MatrixPress(i,k-1); T = MatrixTemp(i,k-1); xCH4 = MatrixFrac_CH4(i,k-1);
    xCO2 = MatrixFrac_CO2(i,k-1); xH2O = MatrixFrac_H2O(i,k-1);
    xCO = MatrixFrac_CO(i,k-1); xH2 = MatrixFrac_H2(i,k-1); 
    xN2 = MatrixFrac_N2(i,k-1); xO2 = MatrixFrac_O2(i,k-1); 

    uz1 = MeshVel(i,k-1); uz2 = MeshVel(i+1,k-1); uz = MatrixVel(i,k-1);
    rho1 = MeshDens(i,k-1); rho2 = MeshDens(i+1,k-1); rho = MatrixDens(i,k-1);
    mu1 = Mesh_mu(i,k-1); mu2 = Mesh_mu(i+1,k-1);
    fe = Ergun(eps,rho2,uz2,d_p,mu2); 
    fw = Ergun(eps,rho1,uz1,d_p,mu1);

    mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
    mN2 = 28.02; mO2 = 32.00;
    M2m = mCH4*xCH4 + mCO*xCO + mCO2*xCO2 + mH2*xH2 + mH2O*xH2O + ...
        mN2*xN2 + mO2*xO2; % Mole to Mass
    
    rho1 = MeshDens(i,k-1); rho2 = MeshDens(i+1,k-1); rho = MatrixDens(i,k-1);
    Cp1 = MeshCp(i,k-1); Cp2 = MeshCp(i+1,k-1); Cp = MatrixCp(i,k-1);
    cond1 = Mesh_cond(i,k-1); cond2 = Mesh_cond(i+1,k-1); cond = Matrix_cond(i,k-1);
    mu = Matrix_Mu(i,k-1);
    
    f1 = 1; f2 = 1;% Permeability, also 'kappa' in derived notes. 
    %cond1 = 0; cond2 = 0; % Put this in here to turn off diffusion. 
    
    U = U_Calc(cond, mu, rho, uz, Cp, eps, d_t, d_p); 
    Hrxn = H_Calc(T);
    rxn = 0;% MatrixSMR1(i,k);
    
    if i == 1
        MatrixMassLHS(i,i) = (rho/P*dz/dt)-(rho2*f2/dz)-(rho1*f1/(dz/2));
        MatrixMassLHS(i,i+1) = (rho2*f2)/dz;
        MatrixMassLHS(i,i+cellnum) = (-rho/T*dz/dt);
        MatrixMassRHS(i,1) = -(rho1*f1/(dz/2))*P_in;
        
        MatrixHeatLHS(i,i+cellnum)= (rho*Cp)*(dz/dt)+rho2*Cp2*uz2+cond1/(dz/2)+cond2/dz;
        MatrixHeatLHS(i,i+1+cellnum)= -cond2/dz;      
        MatrixHeatRHS(i,1) = (rho*Cp)*(dz/dt)*T+(-(4*U/d_t)*(T-T_surr))*(dz)-(-(rho1*Cp1*uz1)-cond1/(dz/2))*T_in;
        
    elseif i == cellnum
        MatrixMassLHS(i,i-1) = (rho1*f1)/dz;
        MatrixMassLHS(i,i) = (rho/P*dz/dt)-(rho2*f2/(dz/2))-(rho1*f1/dz);
        MatrixMassLHS(i,i+cellnum) = (-rho/T*dz/dt);
        MatrixMassRHS(i,1) = -(rho2*f2/(dz/2))*P_out;
        
        MatrixHeatLHS(i,i-1+cellnum)= -(rho1*Cp1*uz1)-cond1/dz;
        MatrixHeatLHS(i,i+cellnum)= (rho*Cp)*(dz/dt)+rho2*Cp2*uz2+cond1/dz;
        MatrixHeatRHS(i,1) = (rho*Cp)*(dz/dt)*T+(-(4*U/d_t)*(T-T_surr))*(dz);
        
    else
        MatrixMassLHS(i,i-1) = (rho1*f1)/dz;
        MatrixMassLHS(i,i) = (rho/P*dz/dt)-(rho2*f2/dz)-(rho1*f1/dz);
        MatrixMassLHS(i,i+1) = (rho2*f2)/dz;
        MatrixMassLHS(i,i+cellnum) = (-rho/T*dz/dt);
        MatrixMassRHS(i,1) = 0;
        
        MatrixHeatLHS(i,i-1+cellnum)= -(rho1*Cp1*uz1)-cond1/dz;
        MatrixHeatLHS(i,i+cellnum)= (rho*Cp)*(dz/dt)+rho2*Cp2*uz2+cond1/dz+cond2/dz;
        MatrixHeatLHS(i,i+1+cellnum)= -cond2/dz;      
        MatrixHeatRHS(i,1) = (rho*Cp)*(dz/dt)*T+(-(4*U/d_t)*(T-T_surr))*(dz);
    end
    
end

MatrixCombLHS = cat(1,MatrixMassLHS,MatrixHeatLHS);
MatrixCombRHS = cat(1,MatrixMassRHS,MatrixHeatRHS);
MatrixSoln = sparse(MatrixCombLHS\MatrixCombRHS);

MatrixPress(:,k)=MatrixSoln(1:cellnum,1);
MatrixTemp(:,k)=MatrixSoln(cellnum+1:cellnum*2,1);

CalcSpec
EOS_TransVect

    if k == timestep/4*1
        disp('25% Complete');
    elseif k == timestep/4*2
        disp('50% Complete');
    elseif k == timestep/4*3
        disp('75% Complete');
    end

end

function f = Ergun(eps, rho, uz, dp, mu)

    Re = rho*uz*dp/(mu);
    f = ((1-eps)/(eps^3))*(1.75+(150*(1-eps))/(Re));

end

function HTC = U_Calc(cond_g, mu_g, rho_g, uz, Cp_g, eps, dt, dp)

    cond_s = 0.05; %KJ/m.s.k, very brave assumption for solid conductivity!

    B = 1.25*((1-eps)/eps)^(10/9); % 1.25 is a shape factor for spheres. 
    lb = cond_g / cond_s;
    
    theta = ((1-lb)*B/((1-lb*B)^2)) * log(1 / (lb * B)) - ...
        (B - 1)/(1 - B * lb) - (B + 1)/2;
    
    cond_e0 = cond_g * ((1 - sqrt(1-eps)) + (2 * sqrt(1-eps)) / (1 - B * lb) * theta);

    a_w0 = 10.21 / (dt^(4/3)) * cond_e0;
    Re = (rho_g * uz * dt)/mu_g; Pr = mu_g * Cp_g / cond_g;
    
    cond_e = cond_e0 + 0.14 * cond_g * Re * Pr; 
    a_w = a_w0 + 0.033 * Re * Pr * cond_g/dp;
    
    a_i  = (8 * cond_e * a_w)/(8 * cond_e + a_w * dt);
    
    HTC = (1/a_i)^-1;
    
end

function dH = H_Calc(T)

    % Specific Heat Capacity coefficients, from Elliot & Lira.
    % CH4, CO2, CO, H2, H2O
    Coeff = [   1   19.25   5.21E-02    1.20E-05   -1.13E-08
                2   30.87  -1.29E-02    2.79E-05   -1.27E-08
                3   19.80   7.34E-02   -5.60E-05    1.72E-08
                4   27.14   9.27E-03   -1.38E-05    7.65E-09
                5   32.24   1.92E-03    1.06E-05   -3.60E-09];

    da = 2 * Coeff(3,2) + 2 * Coeff(4,2) - Coeff(1,2) - Coeff(2,2);
    db = 2 * Coeff(3,3) + 2 * Coeff(4,3) - Coeff(1,3) - Coeff(2,3);
    dc = 2 * Coeff(3,4) + 2 * Coeff(4,4) - Coeff(1,4) - Coeff(2,4);
    dd = 2 * Coeff(3,5) + 2 * Coeff(4,5) - Coeff(1,5) - Coeff(2,5);
    
    % Coefficient to compute dH at 298K.
    B = 229.694188755472;
    
    dH = (da*T + db/2*T^2 + dc/3*T^3 + dd/4*T^4)/1000+B;
    
end