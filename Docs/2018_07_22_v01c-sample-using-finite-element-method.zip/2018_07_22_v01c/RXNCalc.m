function rxns = RXNCalc(P, T, xMCH4, xMCO2, xMH2O, xMCO, xMH2)

% Xu & Froment, 1989
% Steam Methane Reforming on Ni // MgAl2O4 spinel catalyst
% (Pa); (K); (%mol); (%mol); (%mol); (%mol); (%mol);

if xMCH4 == 0
    xMCH4 = 1E-03;
end
if xMCO2 == 0
    xMCO2 = 1E-03;
end
if xMH2O == 0
    xMH2O = 1E-03;
end
if xMCO == 0
    xMCO = 1E-03;
end
if xMH2 == 0
    xMH2 = 1E-03;
end

R = 8.3144598; % m^3*Pa/K/mol or J/K/mol, universal gas constant
P = P/100000; % Convert pressure from Pa to bar; 

% Partial pressures, Pa.
PCH4 = P * xMCH4; PCO2 = P * xMCO2; PH2O = P * xMH2O; PCO = P * xMCO; PH2 = P * xMH2;

% Activation energies and heats of adsorption, KJ/mol.
E1 = 240100; E2 = 67130; E3 = 243900;
H_CO = -70650; H_H2 = -82900; H_CH4 = -38280; H_H2O = 88680;

% Frequency factors & adsorption constants, from Arrhenius' Law, no dim.
k1 = (4.225E15)*exp(-E1/R/T);   KCO = (8.23E-5)*exp(-H_CO/R/T);
k2 = (1.955E6)*exp(-E2/R/T);    KH2 = (6.12E-9)*exp(-H_H2/R/T);
k3 = (1.020E15)*exp(-E3/R/T);   KCH4 = (6.65E-4)*exp(-H_CH4/R/T);
                                KH2O = (1.77E5)*exp(-H_H2O/R/T);
                                
% Equilibrium constants, no dim.
% Calculated using shortcut rules from DeGroote & Froment (1995). 
% Another option would be the rules from Hou & Hughes (2001).
K1 = 10^(-11650/T + 13.076);
K2 = 10^(1910/T - 1.784);
K3 = K1*K2;

% Reaction rates are computed. kmol/kgcat.hr
DEN = (1+KCO*PCO+KH2*PH2+KCH4*PCH4+KH2O*PH2O/PH2);

r1 = (k1/(PH2^2.5))*(PCH4*PH2O - (PH2^3)*PCO/K1)/(DEN^2);
r2 = (k2/(PH2^1))*(PCO*PH2O - PH2*PCO/K2)/(DEN^2);
r3 = (k3/(PH2^3.5))*(PCH4*(PH2O^2) - (PH2^4)*PCO2/K3)/(DEN^2);

% Reaction rates are converted. 
% kmol/kgcat.hr * (1000 mol / kmol) * (1 hr / 3600 s);
r1 = r1 * (1000/1) * (1/3600);
r2 = r2 * (1000/1) * (1/3600);
r3 = r3 * (1000/1) * (1/3600);

% Rates are returned as a vector. 
rxns = [r1; r2; r3];

end