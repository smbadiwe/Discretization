
P_in = 20*101325; P_out = 15*101325; T_in = 823; T_surr = 823; T = T_surr; P = P_in; 
% Specified as molar fractions here... also converted to mass fractions. 
xMCH4_in = 0.3; xMCO2_in = 0.1; xMH2O_in = 0.35; 
xMCO_in = 0.2; xMH2_in = 0.05; 
xMN2_in = 0; xMO2_in = 0;

% Calculating initial tranpsort and thermodynamic properties. 
i = cellnum;
mu = Mix_Visc(P, T, xMCH4_in, xMCO2_in, xMH2O_in, xMCO_in, xMH2_in, xMN2_in, xMO2_in);
cond = Mix_Cond(P, T, xMCH4_in, xMCO2_in, xMH2O_in, xMCO_in, xMH2_in, xMN2_in, xMO2_in);
Cp = Mix_Cp(P, T, xMCH4_in, xMCO2_in, xMH2O_in, xMCO_in, xMH2_in, xMN2_in, xMO2_in);
rho = Mix_Dens(P, T, xMCH4_in, xMCO2_in, xMH2O_in, xMCO_in, xMH2_in, xMN2_in, xMO2_in);
diff = Mix_MolDiff(P, T, xMCH4_in, xMCO2_in, xMH2O_in, xMCO_in, xMH2_in, xMN2_in, xMO2_in);

% Getting mean mass density (g/mol) for gas mixture. 
mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
mN2 = 28.02; mO2 = 32.00;
MoltoMass = mCH4*xMCH4_in + mCO*xMCO_in + mCO2*xMCO2_in + mH2*xMH2_in + ...
    mH2O*xMH2O_in + mN2*xMN2_in + mO2*xMO2_in;
rhoM = rho / (MoltoMass/1000);

% Getting the mass fractions for each species.
xCH4_in = mCH4*xMCH4_in/MoltoMass; xCO2_in = mCO2*xMCO2_in/MoltoMass;
xH2O_in = mH2O*xMH2O_in/MoltoMass; xCO_in = mCO*xMCO_in/MoltoMass;
xH2_in = mH2*xMH2_in/MoltoMass; xN2_in = mN2*xMN2_in/MoltoMass;
xO2_in = mO2*xMO2_in/MoltoMass;
xALL_in = xCH4_in + xCO2_in + xH2O_in + xCO_in + xH2_in + xN2_in + xO2_in;
xMALL_in = xMCH4_in + xMCO2_in + xMH2O_in + xMCO_in + xMH2_in + xMN2_in + xMO2_in;

MeshPress = sparse(ones(facenum,timestep)) * P;
MeshTemp = sparse(ones(facenum,timestep)) * T_in;
MatrixTestPress = sparse(ones(cellnum,timestep)); error_P = 1;
MatrixTestTemp = sparse(ones(cellnum,timestep)); error_T = 1;
MatrixPress = sparse(ones(cellnum,timestep)) * P;
MatrixTemp = sparse(ones(cellnum,timestep)) * T_in;

MeshFracM_CH4 = sparse(ones(facenum,timestep)) * xMCH4_in;
MeshFracM_CO2 = sparse(ones(facenum,timestep)) * xMCO2_in;
MeshFracM_H2O = sparse(ones(facenum,timestep)) * xMH2O_in;
MeshFracM_CO = sparse(ones(facenum,timestep)) * xMCO_in;
MeshFracM_H2 = sparse(ones(facenum,timestep)) * xMH2_in;
MeshFracM_N2 = sparse(ones(facenum,timestep)) * xMN2_in;
MeshFracM_O2 = sparse(ones(facenum,timestep)) * xMO2_in;
MeshFracM_ALL = sparse(ones(facenum,timestep)) * xMALL_in;

MeshFrac_CH4 = sparse(ones(facenum,timestep)) * xCH4_in;
MeshFrac_CO2 = sparse(ones(facenum,timestep)) * xCO2_in;
MeshFrac_H2O = sparse(ones(facenum,timestep)) * xH2O_in;
MeshFrac_CO = sparse(ones(facenum,timestep)) * xCO_in;
MeshFrac_H2 = sparse(ones(facenum,timestep)) * xH2_in;
MeshFrac_N2 = sparse(ones(facenum,timestep)) * xN2_in;
MeshFrac_O2 = sparse(ones(facenum,timestep)) * xO2_in;
MeshFrac_ALL = sparse(ones(facenum,timestep)) * xALL_in;

MatrixFrac_CH4 = sparse(ones(cellnum,timestep)) * xCH4_in;
MatrixFrac_CO2 = sparse(ones(cellnum,timestep)) * xCO2_in;
MatrixFrac_H2O = sparse(ones(cellnum,timestep)) * xH2O_in;
MatrixFrac_CO = sparse(ones(cellnum,timestep)) * xCO_in;
MatrixFrac_H2 = sparse(ones(cellnum,timestep)) * xH2_in;
MatrixFrac_N2 = sparse(ones(cellnum,timestep)) * xN2_in;
MatrixFrac_O2 = sparse(ones(cellnum,timestep)) * xO2_in;
MatrixFrac_ALL = sparse(ones(cellnum,timestep)) * xALL_in;

MatrixFracM_CH4 = sparse(ones(cellnum,timestep)) * xMCH4_in;
MatrixFracM_CO2 = sparse(ones(cellnum,timestep)) * xMCO2_in;
MatrixFracM_H2O = sparse(ones(cellnum,timestep)) * xMH2O_in;
MatrixFracM_CO = sparse(ones(cellnum,timestep)) * xMCO_in;
MatrixFracM_H2 = sparse(ones(cellnum,timestep)) * xMH2_in;
MatrixFracM_N2 = sparse(ones(cellnum,timestep)) * xMN2_in;
MatrixFracM_O2 = sparse(ones(cellnum,timestep)) * xMO2_in;
MatrixFracM_ALL = sparse(ones(cellnum,timestep)) * xMALL_in;

Mesh_mu = sparse(ones(facenum,timestep))*mu;
Mesh_cond = sparse(ones(facenum,timestep))*cond;
MeshCp = sparse(ones(facenum,timestep))*Cp;
MatrixDens = sparse(ones(cellnum,timestep))*rho;
MatrixDensM = sparse(ones(cellnum,timestep))*rhoM;
Matrix_Mu = sparse(ones(cellnum,timestep))*mu;
Matrix_cond = sparse(ones(cellnum,timestep))*cond;
MatrixCp = sparse(ones(cellnum,timestep))*Cp;
Mesh_DCH4 = sparse(ones(facenum,timestep))*diff(1,1);
Mesh_DCO = sparse(ones(facenum,timestep))*diff(2,1);
Mesh_DCO2 = sparse(ones(facenum,timestep))*diff(3,1);
Mesh_DH2 = sparse(ones(facenum,timestep))*diff(4,1);

MeshVel = sparse(ones(facenum,timestep))*u_z; 
MatrixVel = sparse(ones(cellnum,timestep))*u_z;
MeshDens = sparse(ones(facenum,timestep))* rho; 
MeshDensM = sparse(ones(facenum,timestep))* rhoM;
error_rho = 1;
rhobed = 53.5; % kg/m^3 for catalyst bulk density
catdV = rhobed * Acs * dz; % Amount of catalyst (kg) in each segment of bed.

rxn = RXNCalc(P, T, xMCH4_in, xMCO2_in, xMH2O_in, xMCO_in, xMH2_in);
MatrixRXN = ones(cellnum,timestep,3);
MatrixRXN(:,:,1) = MatrixRXN(:,:,1) * rxn(1,1); 
MatrixRXN(:,:,2) = MatrixRXN(:,:,2) * rxn(2,1); 
MatrixRXN(:,:,3) = MatrixRXN(:,:,3) * rxn(3,1); 
