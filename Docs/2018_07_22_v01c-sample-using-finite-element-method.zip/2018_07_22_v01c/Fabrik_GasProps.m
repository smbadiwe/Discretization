
% Test File to build and reference the property models used in the
% simulation. 

T = 973; P = 1*101325; vel = 0.63; Dt = 6.3*10E-3; Acs = pi*Dt^2;
xCH4 = 0.18; xCO2 = 0.18; xH2O = 0; xCO = 0.36; xH2 = 0.27; xN2 = 0; xO2 = 0;

mu_g  = Mix_Visc(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2);
cond_g = Mix_Cond(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2);
Cp_g = Mix_Cp(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2);
rho = Mix_Dens(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2);
diff = Mix_MolDiff(P, T, xCH4, xCO2, xH2O, xCO, xH2, xN2, xO2);

% Getting mean mass density (g/mol) for gas mixture. 
mCH4 = 16.04; mCO2 = 44.02; mH2O = 18.03; mCO = 28.01; mH2 = 2.02; 
mN2 = 28.02; mO2 = 32.00;
MoltoMass = mCH4*xCH4 + mCO*xCO + mCO2*xCO2 + mH2*xH2 + mH2O*xH2O + ...
    mN2*xN2 + mO2*xO2;

% (mol/m^3) = kg/m^3 / (mol/g * (1 kg/1000g))
rhoM = rho / (MoltoMass/1000); 

N_H2 = rhoM * xH2 * vel * Acs;
N_CO2 = rhoM * xCO2 * vel * Acs;
N_CH4 = rhoM * xCH4 * vel * Acs;
N_CO = rhoM * xCO * vel * Acs;

rxn = rate1(P, T, xCH4, xCO2, xH2O, xCO, xH2, vel, rhoM, Acs);

Pr = mu_g * Cp_g / cond_g;