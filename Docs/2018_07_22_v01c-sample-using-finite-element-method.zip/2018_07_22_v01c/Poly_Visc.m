function GasVisc = Poly_Visc(T,s)

% Coefficient Ordering: CH4, CO2, CO, H2-1, H2-2, N2, O2-1, O2-2
% H2O Viscosity covered by IAPWS_Visc.

% Data taken from: 
% Rohsenow, W., Hartnett, J., Cho, Y. (1998). Handbook of Heat Transfer
% (3rd Ed). New York, NY: The McGraw-Hill Companies, Inc. 

Coeff = [   1  2.96827E-01  3.71120E-02   1.21830E-05  -7.02426E-08   7.54327E-11  -2.72372E-14   0
            2 -8.09519E-01  6.03953E-02  -2.82485E-05   9.84378E-09  -1.47315E-12   0             0
            3 -5.24575E-01  7.96060E-02  -7.82295E-05   6.28215E-08  -2.83747E-11   5.31783E-15   0
            4 -1.35666E-01  6.84116E-02  -3.92875E-04   1.89960E-06  -5.23104E-09   7.44910E-12  -4.25094E-15
            5  2.72941E00   2.32244E-02  -7.62879E-06   2.92585E-09  -5.28899E-13   0             0
            6  2.54650E-02  7.53370E-02  -6.51566E-05   4.34945E-08  -1.56225E-11   2.24967E-15   0
            7 -3.97863E-01  8.76059E-02  -7.06412E-05   4.62870E-08  -1.69044E-11   2.53415E-15   0];

% Individual gas viscosities are calculated from a polynomial function: 
% C1 * T + C2 * T^2 + C3 * T^3 + C4 * T^4 + C5 ^ T^5 + C6 * T^6. 

% These are entirely empirical equations. An alternative source for
% empirical relations can be found in Perry's Chemical Engineering
% Handbook.

% One significant alternative would be Chapman-Enskog theory, which stems 
% from the Kinetic Theory of Gases, and is treated as a theoretical method. 
% Another approach would be to use Corresponding States theory, calculating
% gas viscosities based on reduced temperature and pressure. These are both
% discussed in The Properties of Gases and Liquids.

% Viscosities are returned in units of Pa.s
        
switch s
    case 1 % CH4
        GasVisc = Coeff(1,2) + Coeff(1,3) * T + Coeff(1,4) * T^2 + ...
            Coeff(1,5) * T^3 + Coeff(1,6) * T^4 + Coeff(1,7) * T^5 + ...
            Coeff(1,8) * T^6;
    case 2 % CO2
        GasVisc = Coeff(2,2) + Coeff(2,3) * T + Coeff(2,4) * T^2 + ...
            Coeff(2,5) * T^3 + Coeff(2,6) * T^4 + Coeff(2,7) * T^5 + ...
            Coeff(2,8) * T^6;
    case 3 % CO
        GasVisc = Coeff(3,2) + Coeff(3,3) * T + Coeff(3,4) * T^2 + ...
            Coeff(3,5) * T^3 + Coeff(3,6) * T^4 + Coeff(3,7) * T^5 + ...
            Coeff(3,8) * T^6;
    case 4 % H2
        if T < 500 % Temperature limit on correlation @ 500K
            GasVisc = Coeff(4,2) + Coeff(4,3) * T + Coeff(4,4) * T^2 + ...
                Coeff(4,5) * T^3 + Coeff(4,6) * T^4 + Coeff(4,7) * T^5 + ...
                Coeff(4,8) * T^6;
        else
            GasVisc = Coeff(5,2) + Coeff(5,3) * T + Coeff(5,4) * T^2 + ...
                Coeff(5,5) * T^3 + Coeff(5,6) * T^4 + Coeff(5,7) * T^5 + ...
                Coeff(5,8) * T^6;
        end
    case 5 % N2
        GasVisc = Coeff(6,2) + Coeff(6,3) * T + Coeff(6,4) * T^2 + ...
            Coeff(6,5) * T^3 + Coeff(6,6) * T^4 + Coeff(6,7) * T^5 + ...
            Coeff(6,8) * T^6;
    case 6 %O2 
        GasVisc = Coeff(7,2) + Coeff(7,3) * T + Coeff(7,4) * T^2 + ...
            Coeff(7,5) * T^3 + Coeff(7,6) * T^4 + Coeff(7,7) * T^5 + ...
            Coeff(7,8) * T^6;
end

end